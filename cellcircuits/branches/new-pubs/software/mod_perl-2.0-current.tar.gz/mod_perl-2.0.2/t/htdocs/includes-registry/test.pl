print "Content-type: text/html\n\n";

print "Hello World<br>\n";
