$test_require = 'it works';

1;
