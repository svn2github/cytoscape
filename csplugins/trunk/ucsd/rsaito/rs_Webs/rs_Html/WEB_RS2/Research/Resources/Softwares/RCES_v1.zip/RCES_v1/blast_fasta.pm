#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Blast.pm,v 1.1.1.1 2002/04/02 20:25:44 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::blast_fasta;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
use G::Tools::Blast;

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
	     blast
	     fasta
	     blast_fasta
	     blast_only
);

sub fasta{

    local(*RESFILE);
    my($acc_r,$eval_r,$bla_db,$inputfile,$faa) = @_;
    my(@fas) = ();
    my($flag) = 1;
    my($i);
    my(@acc) = @$acc_r;
    my(@eval) = @$eval_r;

    for($i = 1; $i <= $#acc; $i ++){
	if($flag == 1){
#	    system("mkdir res/");
#	    qx!/pub/software/blast.new/fastacmd -d /pub/software/blast.new/db/FormatedDatabases/nr -s $acc[$i] > res/cmd.res!;
	    qx!fastacmd -d $bla_db -s $acc[$i] > res/cmd.res!;
	    qx!fasta33 -QH -b 1 -d 1 $inputfile res/cmd.res > res/fasta.res!;
	    
	    open(RESFILE, "res/fasta.res");
	    while(<RESFILE>){
		if($_ =~ /aa$/){
		    chomp;
		    $_ =~ / ([0-9]+) /;
		    $fas[0] = $1;
		}
		elsif($_ =~ /^  +([0-9]+) residues /){
		    chomp;
		    $fas[1] = $1;
		}
		elsif($_ =~ /^Smith-Waterman/){
		    chomp;
		    $_ =~ /([0-9.]+)% ungapped/;
		    $fas[2] = $1;
		    $_ =~ /\(([0-9]+)-([0-9]+):([0-9]+)-([0-9]+)\)$/;
		    $fas[3] = $2;
		    $fas[4] = $4;
		    $fas[5] = $1;
		    $fas[6] = $3;
		    if($faa eq "gbk" && $fas[2] != 100.000){
			$fas[7] = $eval[$i];
			$fas[8] = $acc[$i];
			$fas[9] = $acc[0];
			$flag = 0;
		    }elsif($faa eq "faa"){
			$fas[7] = $eval[1];
			$fas[8] = $acc[1];
			$fas[9] = $acc[0];
			$flag = 0;
		    }
		    last;
		}
	    }
	    close RESFILE;
	}
    }
    return @fas;
    system("rm -f res/cmd.res");
    system("rm -f res/fasta.res");
}


sub blast{

    local(*RESULTFILE); 
    my($acc) = "";
    my(@acc) = ();
    my(@eval) = ();
    my($bla_db, $inputfile, $p, $e) = @_;

#    system("mkdir res/");
#    qx!blastall -p blastp -d /pub/software/blast.new/db/FormatedDatabases/nr -e 1.0e-100 -i $inputfile > res/blast.res!;
#    qx!blastall -p $p -d $bla_db -e $e -i $inputfile > res/blast.res!;
    _blast($bla_db, $inputfile, -p=>"$p", -e=>"$e", -o=>'res/blast.res'); 
   
    open (RESULTFILE, "res/blast.res");
    while(<RESULTFILE>){
	chomp;
	if($_ =~ /^Query\= /){
	    $acc = $_;
	    $acc =~ s/^Query\= //g;
	    push(@acc, $acc);
	    push(@eval, $acc);
	}
	elsif($_ =~ /^[a-z]+\|([^ ]+)\|/){
	    push(@acc, $1);
	    $_ =~ /([^ ]+)$/;
	    push(@eval, $1);
	}
	elsif($_ =~ /^[a-z]+\|\|([^ ]+)/){
	    push(@acc, $1);
	    $_ =~ /([^ ]+)$/;
	    push(@eval, $1);
	}
	elsif($_ =~ /^>/){ last; }
    }	   	   
    close RESULTFILE;
    return(\@acc, \@eval);
    system("rm -f res/blast.res");
}


sub blast_only{

    local(*RESULTFILE); 
    my($acc) = "";
    my($seqq) = "";
    my($seqs) = "";
    my($seqframe) = "";
    my($dummy);
    my($judge);
    my($result);
    my($flag) = 0;
    my(@fas) = ();
    my ($bla_db, $inputfile, $p, $e, $faa) = @_;

    _blast($bla_db, $inputfile, -p=>"$p", -e=>"$e", -o=>'res/blast.res'); 
   
    open (RESULTFILE, "res/blast.res");
    while(<RESULTFILE>){
	chomp;
	if($_ =~ /^Query\= /){
	    $acc = $_;
	    $acc =~ s/^Query\= //g;
	    $fas[9] = $acc;
	    $dummy = <RESULTFILE>;
	    $dummy =~ /([\d]+) letters/;
	    $fas[0] = $1;
	}
	elsif($_ =~ /^\>BcDNA:([\S]+)/){
	    if($flag == 0){
		$fas[8] = $1;
		$dummy = <RESULTFILE>;
		$dummy =~ /Length \= ([\d]+)/;
		$fas[1] = $1;
		$flag = 1;
	    }
	}
	elsif($_ =~ /^ Score/ && $flag == 1){
	    $_ =~ /Expect \= ([\S]+)/;
	    $fas[7] = $1;
	    $dummy = <RESULTFILE>;
	    $dummy =~ /Identities \= ([\S]+) \(([\d]+)\%\)/;
	    $fas[2] = $2;
	}
	elsif($_ =~ /^Query\: +([\d]+)/){
	    if($flag == 1){ $fas[5] = $1; $flag = 2; }
	    elsif($flag == 3){ 
		$_ =~ / ([\S]+) +([\d]+)$/;
		$seqframe = $1;
		$seqq = $seqq . $seqframe;
	    }
	}
	elsif($_ =~ /^Sbjct\: +([\d]+)/){
	    if($flag == 2){ $fas[6] = $1; $flag = 3; }
	    elsif($flag == 3){ 
		$_ =~ / ([\S]+) +([\d]+)$/;
		$seqframe = $1;
		$seqs = $seqs . $seqframe;
	    }
	}
    }	   	   
    close RESULTFILE;
    $fas[3] = length($seqq);
    $fas[4] = length($seqs);

    if(defined($fas[0])&& defined($fas[1])&& defined($fas[3])&& defined($fas[4])&& defined($fas[9])){
	if($fas[3] == $fas[4]){
	    $judge = "T";
	}
	else{
	    $judge = "F";
	}
	$fas[3] = $fas[5] + $fas[3];
	$fas[4] = $fas[6] + $fas[4];
	$result = "$fas[9]  $fas[0]  $fas[5]  $fas[3]  $fas[8]  $fas[1]  $fas[6]  $fas[4]  $fas[7]  $fas[2]  $judge";
##                  gene    g(c)length  hit area     accession  a(c)length    hit area     e-value  homology  judge;
    }
    return $result;
    system("rm -f res/blast.res");
}

sub tfa_file{

    my($bfinput) = @_;

    open(TFAFILE, ">input.tfa");
    print TFAFILE $bfinput;
    close TFAFILE;

}

sub blast_fasta{

    my $acc;
    my $eval;
    my @fas;
    my ($bla_db, $input, $p, $e, $faa) = @_;
    my $judge;
    my $result = "";
#    my $dummy;

#    system("mkdir res");
#    tfa_file($input);
    ($acc, $eval) = blast($bla_db, $input, $p, $e);
#    print "acc::   @$acc\n";
#    print "eval::  @$eval\n";
    if(defined(@$acc[1]) && @$acc[1] ne ""){
	@fas = fasta($acc,$eval,$bla_db,$input,$faa);
#	print "gene:$fas[9]  fas[0]:$fas[0] 1:$fas[1] 2:$fas[2] 3:$fas[3] 4:$fas[4] 5:$fas[5] 6:$fas[6] 7:$fas[7] 8:$fas[8]\n";
	if(defined($fas[0])&& defined($fas[1])&& defined($fas[3])&& defined($fas[4])&& defined($fas[9])){
	    if(($fas[0] == $fas[3]) && ($fas[1] == $fas[4])){
		$judge = "T";
	    }
	    else{
		$judge = "F";
	    }
	    $result = "$fas[9]  $fas[0]  $fas[5]  $fas[3]  $fas[8]  $fas[1]  $fas[6]  $fas[4]  $fas[7]  $fas[2]  $judge";
##	                gene    g(c)length  hit area     accession  a(c)length    hit area     e-value  homology  judge;

#	    $result = "gene: $fas[9]  g(c): $fas[0] $fas[5] - $fas[3]  accession: $fas[8]  a(c): $fas[1] $fas[6] - $fas[4]  e-value: $fas[7]  homology: $fas[2]  judge: $judge\n";
#	    $result = "gene: $fas[9]  accession: $fas[8]  e-value: $fas[7]  homology: $fas[2]  judge: $judge\n";
#	    $result = "gene: $acc[0]  accession: $acc[1]  e-value: $acc[2]  homology: $fas[2]  g(c): $fas[0] $fas[5] - $fas[3]  a(c): $fas[1] $fas[6] - $fas[4]  judge: $judge\n";
#	    print "Input any letter:";
#	    $dummy = <STDIN>;    
	}
    }    
    return $result;
}

1;
