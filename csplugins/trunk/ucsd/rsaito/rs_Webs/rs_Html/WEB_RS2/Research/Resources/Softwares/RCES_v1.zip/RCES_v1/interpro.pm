#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Blast.pm,v 1.1.1.1 2002/04/02 20:25:44 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::interpro;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
	     save_seq
	     fasta_file
	     scan
	     pro
);

sub save_seq{
    my($seq) = @_;
    my($seq_frag);

    while(<FILE>){
        if($_ =~ /^\>/){
            last;
        }else{
            $seq_frag = $_;
            $seq = $seq . $seq_frag;
        }
    }
    $seq =~ s/[^A-Z]//g;
    chomp $seq;    
    return $seq;
}

sub fasta_file{                          # amino_seq -> fasta_file
    my($name, $amino_acid) = @_;
    my $file_name = 'file.tfa';

    open(FASTAFILE, "> $file_name");
    print FASTAFILE ">$name\n$amino_acid\n";
    close FASTAFILE;
    print "\n Inputfile: $name \n";

    return $file_name;
}

sub scan{

    my($scan) = "";
    my($inputfile, $path) = @_;
    my($iprpath);
    local(*SCANFILE);

    $iprpath = $path.'/iprscan/';
    qx!$iprpath./InterProScan.pl $inputfile +ipr > res/scan.res!;

    open (SCANFILE, "res/scan.res");
    while(<SCANFILE>){
	chomp;
	if($_ =~ /^ results should be in ([^ ]+)/){
	    $scan = $1;
	    $scan =~ s/\/merged.outformat//g;
	}
    }
    close SCANFILE;
    return $scan;
    system("rm -f res/scan.res");
}

sub pro{

    my($scan, $path) = @_;
    my(@pro) = ();
    my($i) = 0;
    local(*RESULTFILE); 

    chdir("$path/iprscan/$scan/");
    system("gmake raw -j1 -k");

    if($scan ne ""){
	open (RESULTFILE, "merged.raw");
	while(<RESULTFILE>){ 
	    chomp;
	    $pro[$i] = $_; 
	    $i ++;
	}
	close RESULTFILE;
	chdir("$path");
	qx!rm -rf $path/iprscan/$scan/!;
    }
    return @pro;
}

1;

__END__

########################### interproscan #######################
#local(*W_FILE);
#local(*DIR);
#my($dir);
#my($scan);
#my(@pro);
#my($pro);
#my($file);
#my($dir_name);
#my($W_file);
#my($dummy);
#
#$dir_name = $ARGV[0];
#$dir_name =~ s/Fastafiles-//g;
#$dir_name =~ s/\///g;
#$W_file = "interpro-result-".$dir_name;
#
#open (W_FILE,"> $W_file");
#opendir (DIR, $ARGV[0]) || die "Cannot open: $!";
#while(defined($dir = readdir(DIR))){
#   if($dir =~ /^[\w]+/){
#	print "dir: $dir\n";
#	$scan = &scan($ARGV[0],$dir);
#	@pro = &interpro($scan);
#	$file = $dir;
#	$file =~ s/.tfa//g;
#	print "file: $file\n";
#	if($file ne ""){
#	    if(@pro == 0){
#		print W_FILE "gene: $file  result: << NO HITS FOUND >>\n"; 
#		print "gene: $file result: <<NO HITS FOUND>>\n";
#		print "Input any letter:";
#		$dummy = <STDIN>;
#	    }else{ 
#		foreach $pro(@pro){
#		    print W_FILE "gene: $file  result: $pro\n"; 
#		    print "gene: $file  result: $pro\n";	
#		    print "Input any letter:";
#		    $dummy = <STDIN>;
#		}
#	    }
#	}
#    }
#}
#closedir DIR;
#close W_FILE;    
#########################################################
