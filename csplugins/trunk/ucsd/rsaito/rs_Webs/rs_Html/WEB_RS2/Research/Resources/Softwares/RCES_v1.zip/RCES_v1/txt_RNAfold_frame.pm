#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Graph.pm,v 1.2 2002/05/27 19:37:55 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::txt_RNAfold_frame;

use strict;
use G::Tools::rnafold;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
             txt_RNAfold_frame
	     stop1and2_graph
             );
$VERSION = '0.01';

#::::::::::::::::::::::::::::::
#        Methods Start
#::::::::::::::::::::::::::::::



sub txt_RNAfold_frame{

    local *FH;
    local *WFH;
    my $end;
    my $flag;
    my $len;
    my $free_E;
    my ($name, $stop1, $stop2, $seq) = @_;
    my $code;
    my $fold;
    my @fold;
    
    if(defined($name)){
        $end = 0;
        $code = "";
        $free_E = "";
    }
    if(defined($seq) && $seq ne ""){
        $end = length($seq);
        for($len = 150; $len >= 50; $len -= 50){
            $flag = 1;
            if($stop1 < $len/2){ $flag = 0; }
            if(($stop2 - $stop1 - 1) < $len){ $flag = 0; }
            if(($end - $stop2 - 1) < $len/2){ $flag = 0; }
            
            if($flag == 1){
                $code = substr($seq, ($stop1 - $len/2) - 1, $len);
                if(defined($code) && $code ne ""){
                    $free_E = RNAfold_original($code);
                    $fold = 'gene: '."$name".'  stop1  len: '."$len".'  Free_Energy: '."$free_E";
		    push(@fold, $fold);
                }

                $code = substr($seq, ($stop2 - $len/2) - 1, $len);
                if(defined($code) && $code ne ""){
                    $free_E = RNAfold_original($code);
                    $fold = 'gene: '."$name".'  stop2  len: '."$len".'  Free_Energy: '."$free_E";
		    push(@fold, $fold);
                }
	    }
	}
    }
    return(@fold);
}    

sub stop1and2_graph{
    my @fold = @_;
    my $fold;
    my $freeE;
    my @r;
    my @s1;
    my @s2;
    my @stop1;
    my @stop2;
    my $i;
    my $g;
    my $j;
    my $v;
    my $c;
    my @mark;
    my $mark;

    foreach $fold(@fold){
	@r = split(/[ \t]+/, $fold);
#	print 'sub r::  '."@r\n";
	$freeE = $r[6];
#	print 'sub r6::  '."$r[6]\n";
	for($i = 0; $i >= -200; $i --){
	    $j = $i - 1;
	    if($freeE <= $i && $freeE > $j){
		if($r[2] eq 'stop1'){ @stop1[($i * -1)] ++; }
		elsif($r[2] eq 'stop2'){ @stop2[($i * -1)] ++; }
		last;
	    }
	}
    }
#    print 'sub stop1::  '."@stop1\n";
#    print 'sub stop2::  '."@stop2\n";

    foreach $v(@stop1){ 
	if($v eq ''){ $v = 0; push(@s1, $v); }
	elsif($v ne ''){ push(@s1, $v); }
    }
    $v = "";
    foreach $v(@stop2){ 
	if($v eq ''){ $v = 0; push(@s2, $v); }
	elsif($v ne ''){ push(@s2, $v); }
    }

    if(scalar(@stop1) >= scalar(@stop2)){
	$g = scalar(@stop1) - scalar(@stop2) - 1;
	for($i = 0; $i <= $g; $i ++){ push(@s2, 0); }
    }else{
	$g = scalar(@stop2) - scalar(@stop1) - 1;
	for($i = 0; $i <= $g; $i ++){ push(@s1, 0); }
    }
    $c = scalar(@s1);
    for($mark = 0; $mark >= (($c - 1)* -1); $mark --){ push(@mark, $mark); }

    return(\@mark, \@s1, \@s2);
}

1;
