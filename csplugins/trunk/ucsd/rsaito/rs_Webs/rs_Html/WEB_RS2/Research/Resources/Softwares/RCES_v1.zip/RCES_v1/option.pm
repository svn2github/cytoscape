#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Blast.pm,v 1.1.1.1 2002/04/02 20:25:44 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::option;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
	     min_ave
	     divide
	     option
);

sub min_ave{
    my @fold = @_;
    my $fold;
    my @name;
    my @min;
    my $min;
    my @ave;
    my $ave;
    my $mark;
    my @r = ();
    my @fe = ();
    my $fe;
    my @c = ();
    my @t;
    my $m;
    my $i;
    my $j = 1;

    foreach $fold(@fold){
	chomp;
	@r = split(/[ \t]+/, $fold); # Divide the line by " " or TAB -> $r[0], $r[1]
	if(@r ne ""){
## minimum
	    $name[0] = "NAME";
	    $name[$j] = $r[0];
	    if($name[$j] ne $name[($j - 1)] && defined($min) && $min != 0){
		$min = "$name[($j - 1)]  mark: $mark  fe_min: $min\n";
		push(@min, $min);
		$min = 0;
	    }else{
		if($r[6] < $min){ $min = $r[6]; $mark = $r[3]; }
	    }
	    $j ++;

## average
	    for($m = -200; $m <= 150; $m = $m + 10){
		if($r[3] == $m){
		    $i = $m + 200;
		    $fe = $r[6];
#		    if(defined($fe[$i]) && $fe[$i] ne ""){ $fe[$i] = $fe[$i] + $fe; print 'option ave fe:: '."$fe[$i]\n"; }
#		    else{ $fe[$i] = 0; }
		    $fe[$i] = $fe[$i] + $fe; 
#		    print 'option ave fe:: '."$fe[$i]\n"; 
		    $c[$i] ++;
		}
	    }
	}
    }

    for($i = 0; $i <= 350; $i = $i +10){
	if(defined($fe[$i]) && $fe[$i] ne ""){
	    $t[$i] = $fe[$i] / $c[$i];
#	    print 'option ave position i:: '."$i\n"; 
#	    print 'option ave position fe:: '."$fe[$i]\n"; 
#	    print 'option ave position c:: '."$c[$i]\n"; 
#	    print 'option ave position t:: '."$t[$i]\n"; 
#	    print "t $t[$i]  fe $fe[$i]  c $c[$i]\n";
	    $m = $i - 200;
#	    $ave = "mark: $m  ave_fe: $t[$i]  total_fe: $fe[$i]  total_seq: $c[$i]\n";
	    $ave = $t[$i];
	    push(@ave, $ave);
	}
    }
    return (\@min, \@ave);
}

sub divide{
    my(@fold) = @_;
    my $fold;
    my @fold_50;
    my @fold_100;
    my @fold_150;

    foreach $fold(@fold){
        if($fold =~ / len: 50 /){ push(@fold_50, $fold); }
        elsif($fold =~ / len: 100 /){ push(@fold_100, $fold); }
        elsif($fold =~ / len: 150 /){ push(@fold_150, $fold); }
    }
    return (\@fold_50, \@fold_100, \@fold_150);
}

sub option{
    my(@fold) = @_;
    my $fold;
    my @fold_50;
    my @fold_100;
    my @fold_150;
    my $min50;
    my $min100;
    my $min150;
    my $ave50;
    my $ave100;
    my $ave150;

    foreach $fold(@fold){
        if($fold =~ / len: 50 /){ push(@fold_50, $fold); }
        elsif($fold =~ / len: 100 /){ push(@fold_100, $fold); }
        elsif($fold =~ / len: 150 /){ push(@fold_150, $fold); }
    }

    ($min50, $ave50) = min_ave(@fold_50);
    ($min100, $ave100) = min_ave(@fold_100);
    ($min150, $ave150) = min_ave(@fold_150);
#    print @$min50;

    return($min50, $ave50, $min100, $ave100, $min150, $ave150);
}
1;
