#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Blast.pm,v 1.1.1.1 2002/04/02 20:25:44 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::rnafold;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
	     RNAfold_original
	     RNAfold_res	     
);

sub RNAfold_original{
    local(*RESULTFILE);
    my($code) = @_;
    my $free_E = "";

    qx!echo $code | RNAfold > res/rnafold.res!;
    
    open(RESULTFILE, "res/rnafold.res");
    while(<RESULTFILE>){
	if($_ =~ /([0-9\.\-]+)\)$/){
	    $free_E = $1;
	}
    }
    close RESULTFILE;
    chomp $free_E;
    return $free_E;
}


sub RNAfold_res{
    my ($name, $dir, $stop, $cds, $utr) = @_;
    my $end = 0;
    my $flag = 1;
    my $seq = $cds.$utr;
    my $mark;
    my $mark_start;
    my $len;
    my $area;
    my $code;
    my $free_E;
    my @fold;
    my $fold;
#    my $dummy;

    if(defined($seq) && $seq ne ""){
	$end = length($seq);
	for($mark = -200; $mark <= 150; $mark = $mark + 10){
	    $mark_start = $stop + $mark;
	    if($mark_start >= 1){
		for($len = 50; $len <= 150; $len += 50){
		    $area = $mark_start + $len;
		    if($area <= $end && $area <= ($stop + 200)){
			$code = substr($seq, $mark_start, $len);
			if(defined($code) && $code ne ""){
			    $free_E = &RNAfold_original($code);
			    $fold = "$name  $dir  mark: $mark  len: $len  $free_E";
##			             Gene  Direction  From_stopcodon   Length      Free_Energy

#			    print "Input any letter:";
#			    $dummy = <STDIN>;

			    push(@fold, $fold);
			}
		    }else{ last; }
		}
	    }
	}
    }
    return @fold;
}
1;
