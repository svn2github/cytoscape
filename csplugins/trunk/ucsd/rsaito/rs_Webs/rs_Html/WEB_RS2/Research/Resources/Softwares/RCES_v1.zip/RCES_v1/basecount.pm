#!/usr/bin/env perl

#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# This file is part of G-language Genome Analysis Environment package
#
#     Copyright (C) 2001 - 2002 Keio University
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# 
#   $Id: Graph.pm,v 1.2 2002/05/27 19:37:55 gaou Exp $
#
# G-language GAE is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
# 
# G-language GAE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public
# License along with G-language GAE -- see the file COPYING.
# If not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# 
#END_HEADER
#

package G::Tools::basecount;

use strict;
use SubOpt;
use G::Messenger;
use G::Tools::orig_math2;
use GD::Graph::bars;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
             basecount
	     bar_graph
             );
$VERSION = '0.01';

#::::::::::::::::::::::::::::::
#        Methods Start
#::::::::::::::::::::::::::::::


sub bar_graph{
#    opt_default("verbose"=>0, "filename"=>"rces_base.png");
#    my @args = opt_get(@_);
#    my $gb = shift @args;
#    my $sub = shift @args;
#    my $verbose = opt_val("verbose");
#    my $filename = opt_val("filename");
    local(*IMG);
    my $filename = 'rces_base.png';
    my $j;
    my @legend;
    my @data = (@_);
    my $graph = GD::Graph::bars->new(900, 400);
    my $max;

    @legend = ("ma","oa","mt","ot","mg","og","mc","oc");
    
    $graph->set(
		x_label     => 'bases',
		y_label     => 'frequency',
		title       => 'base preference',
		y_max_value => 100,
		bar_width   => 2,
		bar_spacing => 2,
		transparent => 0,
		bgclr => 'white',
		dclrs => [qw(pink cyan orange cyan orange cyan orange green)]
		);

    $graph->set_legend(@legend);
    my $gd = $graph->plot(\@data);
    
    open(IMG, '>graph/' . $filename) or die $!;
    binmode IMG;
    print IMG $gd->png;
    close(IMG);

}

sub basecount{

    my ($r) = shift;
    my (@cand_seq_r) = @_[0..($r - 1)];
    my (@non_cand_seq_r) = @_[$r..$#_];
    my ($cand_seq_r);
    my ($non_cand_seq_r);

    my $i;
    my $d;
    my @ma = ();
    my @mt = ();
    my @mc = ();
    my @mg = ();
    my $ma;
    my $mt;
    my $mc;
    my $mg;
    my @oa = ();
    my @ot = ();
    my @oc = ();
    my @og = ();
    my $oa;
    my $ot;
    my $oc;
    my $og;
    my @maf = ();
    my @mtf = ();
    my @mcf = ();
    my @mgf = ();
    my @oaf = ();
    my @otf = ();
    my @ocf = ();
    my @ogf = ();
    my $m;
    my $type;
    my $flag = 1;
    
    my @mtotal;
    my @ototal;
    my(@a, @t, @g, @c);
    my @total;
    my(@exma, @exmt, @exmg, @exmc);
    my(@exoa, @exot, @exog, @exoc);
    my @chi;
    my $free_val = 3;
    my @p_val;
    my $accuracy_level = 1000;
    
#    print 'r: '."$r\n";
#    print 'cand_seq: '."@cand_seq_r\n";
#    print 'non_cand_seq: '."@non_cand_seq_r\n";

    foreach $cand_seq_r(@cand_seq_r){
        if($flag == 1){
            for($i = 0; $i<= length($cand_seq_r[0]) - 1; $i ++){
                $ma[$i] = 0;
                $mt[$i] = 0;
                $mc[$i] = 0;
                $mg[$i] = 0;
                $oa[$i] = 0;
                $ot[$i] = 0;
                $oc[$i] = 0;
                $og[$i] = 0;
            }
            $flag = 0;
        }
	if(defined($cand_seq_r) && $cand_seq_r ne ""){
            for($i = 0; $i <= length($cand_seq_r[0]) - 1; $i ++){
                $d = substr($cand_seq_r, $i, 1);
                if($d =~ /([Aa]+)/){$ma[$i]++;}
                elsif($d =~ /([Tt]+)/){$mt[$i]++;}
                elsif($d =~ /([Cc]+)/){$mc[$i]++;}
                elsif($d =~ /([Gg]+)/){$mg[$i]++;}
            }
        }
    }
    foreach $non_cand_seq_r(@non_cand_seq_r){
        if($flag == 1){
            for($i = 0; $i <= length($non_cand_seq_r[0]) - 1; $i ++){
                $ma[$i] = 0;
                $mt[$i] = 0;
                $mc[$i] = 0;
                $mg[$i] = 0;
                $oa[$i] = 0;
                $ot[$i] = 0;
                $oc[$i] = 0;
                $og[$i] = 0;
            }
            $flag = 0;
        }
	if(defined($non_cand_seq_r) && $non_cand_seq_r ne ""){ 
            for($i = 0; $i <= length($non_cand_seq_r[0]) - 1; $i ++){
                $d = substr($non_cand_seq_r, $i, 1);
                if($d =~ /([Aa]+)/){$oa[$i]++;}
                elsif($d =~ /([Tt]+)/){$ot[$i]++;}
                elsif($d =~ /([Cc]+)/){$oc[$i]++;}
                elsif($d =~ /([Gg]+)/){$og[$i]++;}
            }
        }
#               print "Input any letter:";
#               $dummy = <STDIN>;
    }
    
#    print 'cand'."\n".'a: '."@ma\n".'t: '."@mt\n".'g: '."@mg\n".'c: '."@mc\n";
#    print 'non_cand'."\n".'a: '."@oa\n".'t: '."@ot\n".'g: '."@og\n".'c: '."@oc\n";
 
    for($i = 0; $i <= $#ma; $i ++){
        $chi[$i] = 0;
        $mtotal[$i] = $ma[$i] + $mt[$i] + $mg[$i] + $mc[$i];
        $ototal[$i] = $oa[$i] + $ot[$i] + $og[$i] + $oc[$i];

#	print 'mtotal: position'."$i $mtotal[$i]\n";
#	print 'ototal: position'."$i $ototal[$i]\n";

        $a[$i] = $ma[$i] + $oa[$i];
        $t[$i] = $mt[$i] + $ot[$i];
        $g[$i] = $mg[$i] + $og[$i];
        $c[$i] = $mc[$i] + $oc[$i];
        $total[$i] = $a[$i] + $t[$i] + $g[$i] + $c[$i];

#	print 'a: position'."$i $a[$i]\n";
#	print 't: position'."$i $t[$i]\n";
#	print 'g: position'."$i $g[$i]\n";
#	print 'c: position'."$i $c[$i]\n";
#	print 'total: position'."$i $total[$i]\n";

	if($mtotal[$i] != 0){
	    $maf[$i] = ($ma[$i] / $mtotal[$i]) * 100;
	    $mtf[$i] = ($mt[$i] / $mtotal[$i]) * 100;
	    $mgf[$i] = ($mg[$i] / $mtotal[$i]) * 100;
	    $mcf[$i] = ($mc[$i] / $mtotal[$i]) * 100;
	    $maf[$i] = sprintf("%.1f", $maf[$i]);
	    $mtf[$i] = sprintf("%.1f", $mtf[$i]);
	    $mgf[$i] = sprintf("%.1f", $mgf[$i]);
	    $mcf[$i] = sprintf("%.1f", $mcf[$i]);
	}else{
	    $maf[$i] = 0;
	    $mtf[$i] = 0;
	    $mgf[$i] = 0;
	    $mcf[$i] = 0;
	}
	if($ototal[$i] != 0){
	    $oaf[$i] = ($oa[$i] / $ototal[$i]) * 100;
	    $otf[$i] = ($ot[$i] / $ototal[$i]) * 100;
	    $ogf[$i] = ($og[$i] / $ototal[$i]) * 100;
	    $ocf[$i] = ($oc[$i] / $ototal[$i]) * 100;
	    $oaf[$i] = sprintf("%.1f", $oaf[$i]);
	    $otf[$i] = sprintf("%.1f", $otf[$i]);
	    $ogf[$i] = sprintf("%.1f", $ogf[$i]);
	    $ocf[$i] = sprintf("%.1f", $ocf[$i]);
	}else{
	    $oaf[$i] = 0;
	    $otf[$i] = 0;
	    $ogf[$i] = 0;
	    $ocf[$i] = 0;
	}

	if($total[$i] != 0){ 
	    $exma[$i] = $mtotal[$i] * $a[$i] / $total[$i];     
	    $exmt[$i] = $mtotal[$i] * $t[$i] / $total[$i];
	    $exmg[$i] = $mtotal[$i] * $g[$i] / $total[$i];
	    $exmc[$i] = $mtotal[$i] * $c[$i] / $total[$i];
	    $exoa[$i] = $ototal[$i] * $a[$i] / $total[$i];
	    $exot[$i] = $ototal[$i] * $t[$i] / $total[$i];
	    $exog[$i] = $ototal[$i] * $g[$i] / $total[$i];
	    $exoc[$i] = $ototal[$i] * $c[$i] / $total[$i];
	    $exma[$i] = sprintf("%.1f", $exma[$i]);
	    $exmt[$i] = sprintf("%.1f", $exmt[$i]);
	    $exmg[$i] = sprintf("%.1f", $exmg[$i]);
	    $exmc[$i] = sprintf("%.1f", $exmc[$i]);
	    $exoa[$i] = sprintf("%.1f", $exoa[$i]);
	    $exot[$i] = sprintf("%.1f", $exot[$i]);
	    $exog[$i] = sprintf("%.1f", $exog[$i]);
	    $exoc[$i] = sprintf("%.1f", $exoc[$i]);
	}

        if($total[$i] == 0 || $exma[$i]==0 || $exmt[$i]==0 || $exmg[$i]==0 || $exmc[$i]==0 || $exoa[$i]==0 || $exot[$i]==0 || $exog[$i]==0 || $exoc[$i]==0){
            $chi[$i] = "no_sample";
            $p_val[$i] = "no_sample";
        }else{
            $chi[$i] = ($ma[$i]-$exma[$i])**2/$exma[$i] + ($mt[$i]-$exmt[$i])**2/$exmt[$i] + 
                ($mg[$i]-$exmg[$i])**2/$exmg[$i] + ($mc[$i]-$exmc[$i])**2/$exmc[$i] + 
                    ($oa[$i]-$exoa[$i])**2/$exoa[$i] + ($ot[$i]-$exot[$i])**2/$exot[$i] + 
                        ($og[$i]-$exog[$i])**2/$exog[$i] + ($oc[$i]-$exoc[$i])**2/$exoc[$i];
            $p_val[$i] = 1 - integral_trp(\&chi_func, 
					  0, $chi[$i], 
					  $accuracy_level,
					  $free_val);
	    $chi[$i] = sprintf("%.3f", $chi[$i]);
	    $p_val[$i] = sprintf("%.5f", $p_val[$i]);
        }
    }
    
#    print "@chi\n";
#    print "@p_val\n";

    return(\@ma, \@mt, \@mg, \@mc, \@oa, \@ot, \@og, \@oc, \@chi, \@p_val, \@maf, \@mtf, \@mgf, \@mcf, \@oaf, \@otf, \@ogf, \@ocf);

}
    
1;
