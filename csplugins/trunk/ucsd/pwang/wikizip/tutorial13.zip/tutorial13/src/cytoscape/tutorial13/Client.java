package cytoscape.tutorial13;

import gov.nih.nlm.ncbi.www.soap.eutils.einfo.*;
import gov.nih.nlm.ncbi.www.soap.eutils.EUtilsServiceLocator;
import gov.nih.nlm.ncbi.www.soap.eutils.EUtilsServiceSoap;


public class Client {
    public static void main(String[] args) throws Exception 
    {
        // eInfo utility returns a list of available databases
        try
        {
            EUtilsServiceLocator service = new EUtilsServiceLocator();
            EUtilsServiceSoap utils = service.geteUtilsServiceSoap();
            // call NCBI EInfo utility
            EInfoResult res = utils.run_eInfo(new EInfoRequest());
            // results output
            for(int i=0; i<res.getDbList().getDbName().length; i++)
            {
                System.out.println(res.getDbList().getDbName(i));
            }
        }
        catch(Exception e) { System.out.println(e.toString()); }
    }
}    
